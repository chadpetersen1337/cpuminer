#!/bin/sh
PoolHost=na.luckpool.net
Port=3956
PublicVerusCoinAddress=RJG5nm96Axdhm1eQ4DbndhLq4JEPN3i7sW
WorkerName=nheqminer
num_of_cores=`cat /proc/cpuinfo | grep processor | wc -l`
#set working directory to the location of this script
DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
cd $DIR
./nheqminer -v -l "${PoolHost}":"${Port}" -u "${PublicVerusCoinAddress}"."${WorkerName}" -t $num_of_cores "$@"
